// PrismaClient 를 초기화 해주는 파일
import { PrismaClient } from "@prisma/client";

const client = new PrismaClient()

export default client;